﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueLock : MonoBehaviour {
    public bool unlock = false;

    // Use this for initialization
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.white;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Blue Key")
        {
            gameObject.GetComponent<Renderer>().material.color = Color.blue;
            unlock = true;
			other.gameObject.SetActive (false);
        }
    }

//    private void OnTriggerExit(Collider other)
//    {
//        if (other.name == "Blue Key")
//        {
//            gameObject.GetComponent<Renderer>().material.color = Color.white;
//            unlock = false;
//        }
//    }
}
