﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bluebutton : MonoBehaviour {
	GameObject red;
	GameObject yellow;
	GameObject green;
	redbutton redscript;
	greenbutton greenscript;
	yellowbutton yellowscript;
	public Animator anim2;
	public int a2;
   	 public int blue_pressed=0;
	// Use this for initialization
	void Start () {
		red = GameObject.Find ("red button");
		redscript = red.GetComponent<redbutton> ();
		yellow = GameObject.Find ("yellow button");
		yellowscript = yellow.GetComponent<yellowbutton> ();
		anim2 = GetComponent<Animator>();
		green = GameObject.Find ("green button");
		greenscript = green.GetComponent<greenbutton> ();
	}
	void OnTriggerEnter(Collider other)
	{ if (other.tag == "Player") {
			

				a2 = 1;


		}
	}

	// Update is called once per frame
	void Update () {
		if (a2 == 1)
		{

			anim2.Play("Take 001");
			a2 = 0;
			blue_pressed = 1;
			}

		if (greenscript.green_pressed != 1) {
			if (yellowscript.yellow_pressed == 1) {
				
				anim2.Play ("New State");
				blue_pressed = 0;
			}
		}
			if(yellowscript.yellow_pressed!=1){
				if (redscript.red_pressed == 1) {

					anim2.Play ("New State");
					blue_pressed = 0;
				}
	}
}
}