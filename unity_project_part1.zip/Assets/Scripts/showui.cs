﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class showui : NetworkBehaviour {
	public GameObject uiObject;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void OnTriggerStay (Collider player) {
		if (player.gameObject.tag == "Player") {
			if (isLocalPlayer) {
				uiObject = player.gameObject.transform.GetChild (6).gameObject.transform.GetChild (0).gameObject;
				uiObject.SetActive (true);
			}

		}
	}
	void OnTriggerExit (Collider player) {
		if (uiObject) {
			uiObject.SetActive (false);
		}
	}

}
