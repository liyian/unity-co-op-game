﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Hammer : NetworkBehaviour {
	bool collide = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (!collide) {
			transform.Rotate(Vector3.right * -20);
		}
	}

	void OnCollisionEnter(Collision other){
		collide = true;
	}
}
