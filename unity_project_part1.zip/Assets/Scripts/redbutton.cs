﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class redbutton : MonoBehaviour {
	GameObject blue;
	GameObject yellow;
	GameObject green;
	bluebutton bluescript;
	greenbutton greenscript;
	yellowbutton yellowscript;
	public Animator anim2;
	public int a2;
	public int red_pressed=0;
	// Use this for initialization
	void Start () {
		blue = GameObject.Find ("blue button");
		bluescript = blue.GetComponent<bluebutton> ();
		yellow = GameObject.Find ("yellow button");
		yellowscript = yellow.GetComponent<yellowbutton> ();
		green = GameObject.Find ("green button");
		greenscript = green.GetComponent<greenbutton> ();


		anim2 = GetComponent<Animator>();

	}
	void OnTriggerEnter(Collider other)
	{ 
		if (other.tag == "Player") {
				a2 = 1;
		}
	}
	// Update is called once per frame
	void Update () {
		if (a2 == 1){
			anim2.Play("Take 001");
			a2 = 0;
			red_pressed = 1;
		}
		if (yellowscript.yellow_pressed != 1) {
			if (greenscript.green_pressed == 0) {
				anim2.Play ("New State");
				red_pressed = 0;
			}
			else if (bluescript.blue_pressed == 0) {
				anim2.Play ("New State");
				red_pressed = 0;
			}
		}
	}
}