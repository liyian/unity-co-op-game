﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class baoxianxiang : MonoBehaviour {
	public Animator anim2;
	public int a2;

	GameObject red;
	GameObject yellow;
	GameObject green;GameObject blue;
	redbutton redscript;
	bluebutton bluescript;
	greenbutton greenscript;
	yellowbutton yellowscript;
	// Use this for initialization
	void Start () {
		anim2 = GetComponent<Animator>();
		red = GameObject.Find ("red button");
		redscript = red.GetComponent<redbutton> ();
		yellow = GameObject.Find ("yellow button");
		yellowscript = yellow.GetComponent<yellowbutton> ();

		green = GameObject.Find ("green button");
		greenscript = green.GetComponent<greenbutton> ();
		blue = GameObject.Find ("blue button");
		bluescript = blue.GetComponent<bluebutton> ();
		
	}

	// Update is called once per frame
	void Update () {
		if (redscript.red_pressed==1&&yellowscript.yellow_pressed==1&&greenscript.green_pressed==1&&bluescript.blue_pressed==1) {
			
			anim2.Play("Take 001");


		}
	}
}