﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowLock : MonoBehaviour {
    public bool unlock = false;

	// Use this for initialization
	void Start () {
        gameObject.GetComponent<Renderer>().material.color = Color.white;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerEnter(Collider other)
	{
        if(other.name == "Yellow Key"){
            gameObject.GetComponent<Renderer>().material.color = Color.yellow;
            unlock = true;
			other.gameObject.SetActive (false);
        }
	}

//	private void OnTriggerExit(Collider other)
//	{
//        if (other.name == "Yellow Key")
//        {
//            gameObject.GetComponent<Renderer>().material.color = Color.white;
//            unlock = false;
//        }
//	}
}
