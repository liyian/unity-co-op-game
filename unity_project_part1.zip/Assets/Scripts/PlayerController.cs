﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.Networking;

public class PlayerController : NetworkBehaviour {
	public GameObject bulletPrefab;
    public Text Text;
    public Image ObjectwithImage;
    public Sprite hammer;
    public Sprite cubePicture;
    public GameObject cube;
	public GameObject arm;
	public GameObject thisCamera;
	public Transform bulletSpawn;
	public Transform itemSpawn;
	private Rigidbody rb;
	public float jump_force;
	GameObject uiObject;

	public enum RotationAxes { MouseXAndY = 0, MouseX = 1, MouseY = 2 }
	public RotationAxes axes = RotationAxes.MouseXAndY;
	public float sensitivityX = 15F;
	public float sensitivityY = 15F;
	public float minimumX = -360F;
	public float maximumX = 360F;
	public float minimumY = -60F;
	public float maximumY = 60F;
	float rotationY = 0F;

	private GameObject obj;
	private Vector3 arm_rotation;
	private bool restore = false;
    private bool power = false;
	private int count = 0;
//	private float time = 2.0f;
	private GameObject real_obj;
	bool hold = false;
	bool trigger = false;
	bool drop = false;
	bool tp = false;
	int fire_counter = 0;
    int counter;

	// Use this for initialization
	void Start () {

        if (isServer)
        {
            ObjectwithImage.sprite = cubePicture;
        }
        else
        {
            ObjectwithImage.sprite = hammer;
        }

        obj = bulletPrefab;
		rb = GetComponent<Rigidbody> ();
		uiObject = gameObject.transform.GetChild (6).gameObject.transform.GetChild (0).gameObject;

		// Determine if is local player
		if (!isLocalPlayer) {
			thisCamera.SetActive (false);
			GetComponent<Rigidbody> ().constraints = RigidbodyConstraints.FreezeAll;
		} else {
			if (GetComponent<Rigidbody>())
				GetComponent<Rigidbody>().freezeRotation = true;
		}
	}
	
	// Update is called once per frame
	void Update () {

		// If it is not local player, do not do other things
		if (!isLocalPlayer)
		{
			return;
		}

		// Detect if player hold an item
		if (real_obj && hold) {
			real_obj.transform.position = itemSpawn.transform.position;
			real_obj.transform.rotation = itemSpawn.transform.rotation;
		} 
		// Detect if player drop an item
		else if (real_obj && !hold && drop) {
			real_obj.transform.eulerAngles = new Vector3 (0, itemSpawn.transform.eulerAngles.y, 0);
			real_obj.transform.position = new Vector3 (itemSpawn.transform.position.x,
				0, itemSpawn.transform.position.z);
			drop = false;
		} 

		// player click primary button on mouse to act
		if (Input.GetMouseButtonDown (0)) {
			if (!restore) {
				arm.transform.Rotate (20, 0, 0);
				restore = true;
			}
			// If player click primary button on mouse when he or she is holding something, the flag will change to drop
			if (hold) {
				hold = false;
				trigger = false;
				drop = true;
				// If player does not use teleport, then remove his or her authority directly
				if (!tp) {
					Debug.Log ("Remove");
					Cmd_RemoveLocalAuthority (real_obj);
				} 
				// Else, his or her authority will remove after they teleport the item and exit teleport's trigger
				else {
					Debug.Log ("Not Remove");
				}
			}
			// If player active a holdable item's tigger, he or she can hold this item on hands
			if (trigger) {
				hold = true;
				// and give this player authority directly to change this object's position
				Cmd_AssignLocalAuthority (real_obj);
			}
		}

		// player jump action
		if(Input.GetKeyDown(KeyCode.Space)){
			// Check if player is on the ground
			if (Mathf.Abs (rb.velocity.y) < 0.001) {
				rb.AddForce (new Vector3 (0.0f, 1.0f, 0.0f) * jump_force);
			}
		}

		// server and client have different abilities
		if (!isServer) {
            obj = bulletPrefab;

		} else {
            obj = cube;

		}

		// arm rotation restore
		count += 1;
		if (restore) {
			if (count % 30 == 0) {
				arm.transform.Rotate (-20, 0, 0);
				restore = false;
			}
		}

		// movement action
		var x = Input.GetAxis("Horizontal") * Time.deltaTime * 3.0f;
		var z = Input.GetAxis("Vertical") * Time.deltaTime * 3.0f;

		transform.Translate(x, 0, 0);
		transform.Translate(0, 0, z);

		// shoot and create
		if (Input.GetKeyDown("c") && power && fire_counter < 3)
		{
			CmdFire();
			fire_counter += 1;
            counter = 3 - fire_counter;
        }

		// mouse look action
		if (axes == RotationAxes.MouseXAndY)
		{
			float rotationX = transform.localEulerAngles.y + Input.GetAxis("Mouse X") * sensitivityX;

			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);

			transform.localEulerAngles = new Vector3(-rotationY, rotationX, 0);
		}
		else if (axes == RotationAxes.MouseX)
		{
			transform.Rotate(0, Input.GetAxis("Mouse X") * sensitivityX, 0);
		}
		else
		{
			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);

			transform.localEulerAngles = new Vector3(-rotationY, transform.localEulerAngles.y, 0);
		}
        Text.text = " " + counter;
    }

	void OnTriggerEnter(Collider other)
	{
		// If player collide with objects with "Item" tag, they can hold them
		if (other.gameObject.CompareTag ("Item") || other.gameObject.CompareTag ("key1") || other.gameObject.CompareTag ("key2")) {
			if (!hold) { 
				real_obj = other.gameObject;  // get the reference of this object
				trigger = true;               // set "trigger" flag to true
			}
		} 
		// If player collide the teleport, change the "tp" flag
		if (other.gameObject.CompareTag ("Teleport")) {
			tp = true;                        // set "tp" flag to true
		}

        // If player collide with the power ball, gain the super power
        if(other.gameObject.CompareTag("PowerBall")){
			counter = 3;
            power = true;
            //If not Server, do not do the Rpc call
            if (!isServer)
            {
                return;
            }
            Rpc_DestroyPowerBall(other.gameObject);
        }
	}

	void OnTriggerStay(Collider other){
		if(other.gameObject.CompareTag("bullet")){
			//If not Server, do not do the Rpc call
			if (isServer) return;
			if (Input.GetKeyDown ("f")) {
				if (fire_counter >= 1) {
					fire_counter -= 1;
					counter = 3 - fire_counter;
				}
				Cmd_DestroyPowerBall (other.gameObject);
				other.gameObject.SetActive (false);
			}
		}

		if (other.gameObject.CompareTag ("cube")) {
			if (!isServer) return;
			if (Input.GetKeyDown ("f")) {
				if (fire_counter >= 1) {
					fire_counter -= 1;
					counter = 3 - fire_counter;
                }
				Rpc_DestroyPowerBall (other.gameObject);
			}
		}

		if (other.gameObject.tag == "paper") {
			if (isLocalPlayer) {
				uiObject.SetActive (true);
			}

		}
	}

	void OnTriggerExit(Collider other){
		// If player exit the teleport, change the "tp" flag back to default
		if (other.gameObject.CompareTag ("Teleport")) {
			tp = false;                       // set "tp" flag to false
		}

		if (other.gameObject.tag == "paper") {
			if (isLocalPlayer) {
				uiObject.SetActive (false);
			}
		}
	}

	public override void OnStartLocalPlayer()
	{
		// Change the local player's color to blue
		GetComponent<MeshRenderer>().material.color = Color.white;
	}

	[Command]
	void CmdFire()
	{
		// Create the Bullet from the Bullet Prefab
		var bullet = (GameObject)Instantiate (
			obj,
			bulletSpawn.position,
			bulletSpawn.rotation);

		// Add velocity to the bullet
		bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * -6;

		// Spawn the bullet on the Clients
		NetworkServer.Spawn(bullet);

		// Destroy the bullet after 2 seconds
//		Destroy(bullet, time);
	}

	// Helper function to assign authority to client
	[Command]
	void Cmd_AssignLocalAuthority (GameObject obj) {
		NetworkInstanceId nIns = obj.GetComponent<NetworkIdentity> ().netId;
		GameObject client = NetworkServer.FindLocalObject (nIns);
		NetworkIdentity ni = client.GetComponent<NetworkIdentity> ();
		ni.AssignClientAuthority(connectionToClient);
	}

	// Helper function to remove authority to client
	[Command]
	void Cmd_RemoveLocalAuthority (GameObject obj) {
		NetworkInstanceId nIns = obj.GetComponent<NetworkIdentity> ().netId;
		GameObject client = NetworkServer.FindLocalObject (nIns);
		NetworkIdentity ni = client.GetComponent<NetworkIdentity> ();
		ni.RemoveClientAuthority (ni.clientAuthorityOwner);
	}
    // Helper function to destroy the power ball
    [ClientRpc]
    void Rpc_DestroyPowerBall(GameObject obj) {
        obj.SetActive(false);
    }

	[Command]
	void Cmd_DestroyPowerBall(GameObject obj) {
		obj.SetActive(false);
	}

	// Helper function that will be called when player exit the "Teleport" trigger.
	void RemoveAuthority(){
		Cmd_RemoveLocalAuthority (real_obj);   // remove client's authority
	}
}
