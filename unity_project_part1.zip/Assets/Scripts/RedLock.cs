﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RedLock : MonoBehaviour {
    public bool unlock = false;

    // Use this for initialization
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.white;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Red Key")
        {
            gameObject.GetComponent<Renderer>().material.color = Color.red;
            unlock = true;
			other.gameObject.SetActive (false);
        }
    }

//    private void OnTriggerExit(Collider other)
//    {
//        if (other.name == "Red Key")
//        {
//            gameObject.GetComponent<Renderer>().material.color = Color.white;
//            unlock = false;
//        }
//    }
}
