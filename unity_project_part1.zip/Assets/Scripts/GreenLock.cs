﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenLock : MonoBehaviour {
    public bool unlock = false;

    // Use this for initialization
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.white;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void OnTriggerEnter(Collider other)
    {
        if (other.name == "Green Key")
        {
            gameObject.GetComponent<Renderer>().material.color = Color.green;
            unlock = true;
			other.gameObject.SetActive (false);
        }
    }

//    private void OnTriggerExit(Collider other)
//    {
//        if (other.name == "Green Key")
//        {
//            gameObject.GetComponent<Renderer>().material.color = Color.white;
//            unlock = false;
//        }
//    }
}
