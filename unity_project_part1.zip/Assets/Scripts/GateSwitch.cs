﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GateSwitch : MonoBehaviour {
    //Boolean used for tracking whether the door should open
    public bool open = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private void OnCollisionEnter(Collision collision)
	{
        if(collision.other.CompareTag("bullet")){
            open = true;
            gameObject.GetComponent<Renderer>().material.color = Color.green;
        }
	}
}
