﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class keytrigger : MonoBehaviour {
	public Animator anim2;
	public int a2;

	// Use this for initialization
	void Start () {
		anim2 = GetComponent<Animator>();

	}
	void OnTriggerEnter(Collider other)
	{ 
		if (other.tag == "key1") {
			a2=1;
			other.gameObject.SetActive (false);
		}
	}

	// Update is called once per frame
	void Update () {
		if (a2 == 1){
			anim2.Play("Take 001");
		}
	}
}