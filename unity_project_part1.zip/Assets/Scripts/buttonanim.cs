﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buttonanim: MonoBehaviour {
	public Animator anim1;
	public int a1;

	// Use this for initialization
	void Start () {
		anim1 = GetComponent<Animator>();

	}
	void OnTriggerEnter(Collider other)
	{ if (other.tag == "bullet") {

			a1=1;

		}
	}

	// Update is called once per frame
	void Update () {
		if (a1 == 1)
		{

			anim1.Play("Take 001");


		}
	}
}