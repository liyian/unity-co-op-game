﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gate : MonoBehaviour {
	public Animator anim2;
	public GameObject GateSwitch;
    GateSwitch GateSwitch_script;
	// Use this for initialization
	void Start () {
        GateSwitch_script = GateSwitch.GetComponent<GateSwitch> ();
	}
	
	// Update is called once per frame
	void Update () {
        if (GateSwitch_script.open == true) {
			anim2.Play("Take 001");
		}
	}

}
